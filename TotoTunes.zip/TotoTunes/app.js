// TotoTunes front end. It talks only to our own Netlify Functions,
// never to Suno directly, so the API key stays secret on the server.

const $ = (id) => document.getElementById(id);
const form = $("form");
const msg = $("msg");
const go = $("go");
const songs = $("songs");
let mode = "simple";

// Switch between "Quick" and "Write my own lyrics"
document.querySelectorAll(".tabs button").forEach((btn) => {
  btn.addEventListener("click", () => {
    mode = btn.dataset.mode;
    document.querySelectorAll(".tabs button").forEach((b) => b.setAttribute("aria-selected", String(b === btn)));
    document.querySelectorAll("[data-show]").forEach((el) => (el.hidden = el.dataset.show !== mode));
    syncLyrics();
  });
});

// Style idea chips fill the style box
document.querySelectorAll(".chip").forEach((chip) =>
  chip.addEventListener("click", () => { $("style").value = chip.textContent; $("style").focus(); })
);

// No vocals = no lyrics needed
$("instrumental").addEventListener("change", syncLyrics);
function syncLyrics() { $("lyrics").disabled = $("instrumental").checked; }

// Remember the access code for this browser tab only
$("password").value = sessionStorage.getItem("tt-pass") || "";

function say(text, isError = false) { msg.textContent = text; msg.classList.toggle("error", isError); }

function headers() {
  const pass = $("password").value.trim();
  try { sessionStorage.setItem("tt-pass", pass); } catch {}
  const h = { "Content-Type": "application/json" };
  if (pass) h["x-app-password"] = pass;
  return h;
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const instrumental = $("instrumental").checked;
  const payload = { customMode: mode === "custom", instrumental, model: $("model").value, style: $("style").value };

  if (mode === "simple") {
    payload.prompt = $("prompt").value;
    if (!payload.style.trim()) return say("Add a sound and style, or tap one of the ideas.", true);
  } else {
    payload.title = $("title").value;
    payload.lyrics = $("lyrics").value;
    payload.vocalGender = $("voice").value;
    if (!payload.style.trim() && (instrumental || !payload.lyrics.trim()))
      return say("Add a sound and style, or some lyrics.", true);
  }

  go.disabled = true;
  say("Sending your idea to Suno…");
  try {
    const r = await fetch("/.netlify/functions/generate", { method: "POST", headers: headers(), body: JSON.stringify(payload) });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || "Couldn't start the song. Try again.");
    say("Making your song. This usually takes 1 to 3 minutes. You can keep this page open.");
    track(data.taskId);
  } catch (err) {
    say(err.message, true);
    go.disabled = false;
  }
});

// Check on the song every 6 seconds until it's ready
async function track(taskId) {
  const empty = songs.querySelector(".empty");
  if (empty) empty.remove();
  const box = document.createElement("div");
  box.className = "batch";
  box.innerHTML = `<div class="waiting"><div class="disc"></div><span>Writing and recording…</span></div>`;
  songs.prepend(box);

  const started = Date.now();
  while (Date.now() - started < 10 * 60 * 1000) {
    await new Promise((res) => setTimeout(res, 6000));
    try {
      const r = await fetch(`/.netlify/functions/status?taskId=${encodeURIComponent(taskId)}`, { headers: headers() });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error);
      if (data.failed) { box.remove(); say(data.error, true); go.disabled = false; return; }
      const playable = data.tracks.filter((t) => t.audio || t.stream);
      if (playable.length) render(box, playable, data.done);
      if (data.done) { say("Your song is ready. Press play."); go.disabled = false; return; }
    } catch (err) {
      // A single failed check isn't fatal; keep trying.
      console.warn(err);
    }
  }
  say("This is taking longer than usual. Try again in a few minutes.", true);
  go.disabled = false;
}

function render(box, tracks, done) {
  box.innerHTML = "";
  tracks.forEach((t) => {
    const el = document.createElement("article");
    el.className = "song";
    const disc = document.createElement("div");
    disc.className = "disc";
    if (t.image) disc.style.backgroundImage = `url("${t.image.replace(/"/g, "")}")`;
    const info = document.createElement("div");
    const h = document.createElement("h3");
    h.textContent = t.title || "Untitled";
    const tags = document.createElement("p");
    tags.className = "tags";
    tags.textContent = t.tags || "";
    const audio = document.createElement("audio");
    audio.controls = true;
    audio.preload = "none";
    audio.src = t.audio || t.stream;
    audio.addEventListener("play", () => disc.classList.add("spin"));
    audio.addEventListener("pause", () => disc.classList.remove("spin"));
    audio.addEventListener("ended", () => disc.classList.remove("spin"));
    info.append(h, tags, audio);
    if (done && t.audio) {
      const a = document.createElement("a");
      a.className = "dl";
      a.href = t.audio;
      a.target = "_blank";
      a.rel = "noopener";
      a.textContent = "Download MP3";
      info.append(a);
    } else if (!done) {
      const p = document.createElement("p");
      p.className = "tags";
      p.textContent = "Preview is playing early. The final file is still finishing.";
      info.append(p);
    }
    el.append(disc, info);
    box.append(el);
  });
}
