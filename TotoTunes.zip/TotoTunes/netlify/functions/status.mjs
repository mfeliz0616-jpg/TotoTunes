import { SUNO_BASE, json, checkAccess, getKey, sunoMessage } from "./_shared.mjs";

const FAILED = {
  CREATE_TASK_FAILED: "Suno couldn't start this song. Try again.",
  GENERATE_AUDIO_FAILED: "Suno couldn't finish this song. Try again with different words.",
  CALLBACK_EXCEPTION: "Something went wrong while finishing the song. Try again.",
  SENSITIVE_WORD_ERROR: "Suno blocked some of the words. Change the description or lyrics and try again.",
};

export default async (req) => {
  const denied = checkAccess(req);
  if (denied) return denied;

  const taskId = new URL(req.url).searchParams.get("taskId");
  if (!taskId || !/^[\w-]{1,100}$/.test(taskId)) return json(400, { error: "Missing song ID." });

  try {
    const r = await fetch(`${SUNO_BASE}/api/v1/generate/record-info?taskId=${encodeURIComponent(taskId)}`, {
      headers: { Authorization: `Bearer ${getKey()}` },
    });
    const data = await r.json().catch(() => ({}));
    if (data.code !== 200) return json(502, { error: sunoMessage(data.code, data.msg) });

    const status = data.data?.status || "PENDING";
    const tracks = (data.data?.response?.sunoData || []).map((t) => ({
      id: t.id,
      title: t.title,
      tags: t.tags,
      image: t.image_url,
      audio: t.audio_url || "",
      stream: t.stream_audio_url || "",
      duration: t.duration,
    }));
    return json(200, {
      status,
      done: status === "SUCCESS",
      failed: !!FAILED[status],
      error: FAILED[status] || data.data?.errorMessage || null,
      tracks,
    });
  } catch (e) {
    return json(500, { error: e.message || "Couldn't reach Suno." });
  }
};
