import { SUNO_BASE, json, checkAccess, getKey, sunoMessage } from "./_shared.mjs";

const MODELS = ["V6", "V6_MINI", "V6_WILD"];

export default async (req) => {
  if (req.method !== "POST") return json(405, { error: "Use POST." });
  const denied = checkAccess(req);
  if (denied) return denied;

  let input;
  try { input = await req.json(); } catch { return json(400, { error: "Bad request." }); }

  const custom = !!input.customMode;
  const instrumental = !!input.instrumental;
  const model = MODELS.includes(input.model) ? input.model : "V6";
  const clip = (v, n) => (typeof v === "string" ? v.trim().slice(0, n) : "");

  // callBackUrl is required by Suno. We point it at our own small function,
  // but the app actually checks progress by polling the status function.
  const origin = process.env.URL || new URL(req.url).origin;
  const body = { customMode: custom, instrumental, model, callBackUrl: `${origin}/.netlify/functions/callback` };

  if (custom) {
    const title = clip(input.title, 80);
    const style = clip(input.style, 1000);
    const lyrics = instrumental ? "" : clip(input.lyrics, 5000);
    if (!style && !lyrics) return json(400, { error: "Add a style, or some lyrics, to make a song." });
    if (title) body.title = title;
    if (style) body.style = style;
    if (lyrics) body.lyrics = lyrics;
    if (!instrumental && (input.vocalGender === "m" || input.vocalGender === "f")) body.vocalGender = input.vocalGender;
    const d = Number(input.duration);
    if (d >= 10 && d <= 360) body.duration = Math.round(d);
  } else {
    const prompt = clip(input.prompt, 3000);
    const style = clip(input.style, 1000);
    if (!style) return json(400, { error: "Add a style, like “lo-fi, chill”, so Suno knows the sound you want." });
    if (prompt) body.prompt = prompt;
    body.style = style;
  }

  try {
    const r = await fetch(`${SUNO_BASE}/api/v1/generate`, {
      method: "POST",
      headers: { Authorization: `Bearer ${getKey()}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await r.json().catch(() => ({}));
    if (data.code !== 200 || !data.data?.taskId) {
      return json(502, { error: sunoMessage(data.code, data.msg) });
    }
    return json(200, { taskId: data.data.taskId });
  } catch (e) {
    return json(500, { error: e.message || "Couldn't reach Suno. Try again." });
  }
};
