// Shared helpers for the Netlify Functions.
// The Suno API key is read from Netlify's environment variables (SUNO_API_KEY),
// so it never appears in the browser or in this public repository.

export const SUNO_BASE = "https://api.sunoapi.org";

export function json(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

// Optional: if APP_PASSWORD is set in Netlify, visitors must enter it.
// This stops strangers from spending your Suno credits.
export function checkAccess(req) {
  const required = process.env.APP_PASSWORD;
  if (!required) return null;
  const given = req.headers.get("x-app-password") || "";
  if (given !== required) {
    return json(401, { error: "That access code isn't right. Check it and try again." });
  }
  return null;
}

export function getKey() {
  const key = process.env.SUNO_API_KEY;
  if (!key) {
    throw new Error("The server is missing SUNO_API_KEY. Add it in Netlify under Site configuration → Environment variables, then redeploy.");
  }
  return key;
}

// Suno returns its own codes inside the JSON body. Turn them into plain messages.
export function sunoMessage(code, msg) {
  const map = {
    400: "Some settings weren't accepted. Check the fields and try again.",
    401: "The Suno API key was rejected. Check SUNO_API_KEY in Netlify.",
    405: "Too many requests right now. Wait a minute and try again.",
    413: "The description or lyrics are too long. Shorten them and try again.",
    429: "Your Suno account is out of credits. Top up at sunoapi.org.",
    430: "Requests are coming in too fast. Wait a moment and try again.",
    455: "Suno is under maintenance. Try again later.",
  };
  return map[code] || msg || "Suno returned an error. Try again.";
}
