// Suno requires a callback URL. We simply acknowledge it;
// the app gets results by polling the status function instead.
export default async () => new Response("ok", { status: 200 });
