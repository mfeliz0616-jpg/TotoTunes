# TotoTunes

A simple web app for making songs with AI, powered by [Suno API](https://sunoapi.org/) and hosted on Netlify.

## How it works

- The page (`index.html`, `styles.css`, `app.js`) is what visitors see.
- When someone presses "Make my song", the page asks a small server function (`netlify/functions/generate.mjs`) to start the song.
- The page then checks progress every few seconds through `netlify/functions/status.mjs` until the song is ready.
- The Suno API key lives **only** in Netlify's settings. It is never in this code, so it's safe for this repo to be public.

## Setting it up on Netlify

1. In Netlify, choose **Add new site → Import an existing project**, and pick this GitHub repo.
2. Leave the build settings as they are (`netlify.toml` already handles them).
3. Go to **Site configuration → Environment variables** and add:
   - `SUNO_API_KEY` = your key from sunoapi.org (required)
   - `APP_PASSWORD` = any code you choose (optional, but recommended so strangers can't use up your credits)
4. Redeploy the site so it picks up the new variables.

If you set `APP_PASSWORD`, open **More settings** on the page and type the code in the **Access code** box.

## Notes

- Each request makes two versions of a song and uses Suno credits.
- Suno keeps generated songs for 14 days, so download any you want to keep.
